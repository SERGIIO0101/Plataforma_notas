<?php
session_start();
// Generar CSRF token si no existe
if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Registrar Usuario - Plataforma Notas</title>
  <link rel="stylesheet" href="../../../assets/styles/styles.css">
</head>
<body>
  <div class="contenedor">
    <?php if (isset($_SESSION['error'])): ?>
      <div class="error"><?php echo htmlspecialchars($_SESSION['error']); unset($_SESSION['error']); ?></div>
    <?php elseif (isset($_SESSION['success'])): ?>
      <div class="success"><?php echo htmlspecialchars($_SESSION['success']); unset($_SESSION['success']); ?></div>
    <?php endif; ?>

    <form action="../../../controllers/procesar-registro.php" method="POST" class="form-registro">
      <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
      <h2>Registrar Nuevo Usuario</h2>

      <label for="nombre">Nombre</label>
      <input type="text" id="nombre" name="nombre" placeholder="Nombre completo" required>

      <label for="email">Correo electrónico</label>
      <input type="email" id="email" name="email" placeholder="usuario@ejemplo.com" required>

      <label for="password">Contraseña</label>
      <input type="password" id="password" name="password" placeholder="Contraseña" required>

      <label for="rol">Rol</label>
      <select id="rol" name="rol" required>
        <option value="">--Selecciona un rol--</option>
        <option value="admin">Admin</option>
        <option value="profesor">Profesor</option>
        <option value="estudiante">Estudiante</option>
      </select>

      <button type="submit">Registrar</button>
    </form>

    <p><a href="ver_usuarios.php">← Volver a lista de usuarios</a></p>
  </div>
</body>
</html>
